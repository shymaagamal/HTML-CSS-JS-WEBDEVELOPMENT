var userFullName  = "userFullName" 
var userAge = 25 
var x 
x= 50

var i = 0, j = 0, k = 0;

var x  = null
typeof(x)